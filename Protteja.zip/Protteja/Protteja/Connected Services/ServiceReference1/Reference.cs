﻿namespace ServiceReference1
{
    using System.Runtime.Serialization;
    
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name="User", Namespace="http://schemas.datacontract.org/2004/07/WSAcademiaSeguros.Entities")]
    public partial class User : object
    {
        
        private string AddressField;
        
        private string AddressNumberField;
        
        private string CityField;
        
        private string CountyField;
        
        private string DocumentNumberField;
        
        private ServiceReference1.EnumUserDocumentType DocumentTypeField;
        
        private string EmailField;
        
        private string NameField;
        
        private string NeighborhoodField;
        
        private string NifField;
        
        private string PhoneField;
        
        private string PhotoField;
        
        private string ProvinceField;
        
        private ServiceReference1.EnumUserTitle TitleField;
        
        private ServiceReference1.EnumUserType TypeField;
        
        private string UsernameField;
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Address
        {
            get
            {
                return this.AddressField;
            }
            set
            {
                this.AddressField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string AddressNumber
        {
            get
            {
                return this.AddressNumberField;
            }
            set
            {
                this.AddressNumberField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string City
        {
            get
            {
                return this.CityField;
            }
            set
            {
                this.CityField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string County
        {
            get
            {
                return this.CountyField;
            }
            set
            {
                this.CountyField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string DocumentNumber
        {
            get
            {
                return this.DocumentNumberField;
            }
            set
            {
                this.DocumentNumberField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public ServiceReference1.EnumUserDocumentType DocumentType
        {
            get
            {
                return this.DocumentTypeField;
            }
            set
            {
                this.DocumentTypeField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Email
        {
            get
            {
                return this.EmailField;
            }
            set
            {
                this.EmailField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Name
        {
            get
            {
                return this.NameField;
            }
            set
            {
                this.NameField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Neighborhood
        {
            get
            {
                return this.NeighborhoodField;
            }
            set
            {
                this.NeighborhoodField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Nif
        {
            get
            {
                return this.NifField;
            }
            set
            {
                this.NifField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Phone
        {
            get
            {
                return this.PhoneField;
            }
            set
            {
                this.PhoneField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Photo
        {
            get
            {
                return this.PhotoField;
            }
            set
            {
                this.PhotoField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Province
        {
            get
            {
                return this.ProvinceField;
            }
            set
            {
                this.ProvinceField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public ServiceReference1.EnumUserTitle Title
        {
            get
            {
                return this.TitleField;
            }
            set
            {
                this.TitleField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public ServiceReference1.EnumUserType Type
        {
            get
            {
                return this.TypeField;
            }
            set
            {
                this.TypeField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Username
        {
            get
            {
                return this.UsernameField;
            }
            set
            {
                this.UsernameField = value;
            }
        }
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name="EnumUserDocumentType", Namespace="http://schemas.datacontract.org/2004/07/WSAcademiaSeguros.Entities")]
    public enum EnumUserDocumentType : int
    {
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        NotDefinied = 0,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        BI = 1,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        CC = 2,
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name="EnumUserTitle", Namespace="http://schemas.datacontract.org/2004/07/WSAcademiaSeguros.Entities")]
    public enum EnumUserTitle : int
    {
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        NotDefinied = 0,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        Eng = 1,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        Sr = 2,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        Sra = 3,
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name="EnumUserType", Namespace="http://schemas.datacontract.org/2004/07/WSAcademiaSeguros.Entities")]
    public enum EnumUserType : int
    {
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        NotDefinied = 0,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        Particular = 1,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        Company = 2,
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name="Operation", Namespace="http://schemas.datacontract.org/2004/07/WSAcademiaSeguros.Entities")]
    public partial class Operation : object
    {
        
        private string DescriptionField;
        
        private System.DateTime DtOperationField;
        
        private string NumberField;
        
        private ServiceReference1.EnumOperationType OperationTypeField;
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Description
        {
            get
            {
                return this.DescriptionField;
            }
            set
            {
                this.DescriptionField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public System.DateTime DtOperation
        {
            get
            {
                return this.DtOperationField;
            }
            set
            {
                this.DtOperationField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Number
        {
            get
            {
                return this.NumberField;
            }
            set
            {
                this.NumberField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public ServiceReference1.EnumOperationType OperationType
        {
            get
            {
                return this.OperationTypeField;
            }
            set
            {
                this.OperationTypeField = value;
            }
        }
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name="EnumOperationType", Namespace="http://schemas.datacontract.org/2004/07/WSAcademiaSeguros.Entities")]
    public enum EnumOperationType : int
    {
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        NotDefined = 0,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        Auto = 1,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        Travel = 2,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        Infomration = 3,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        Message = 4,
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name="Policy", Namespace="http://schemas.datacontract.org/2004/07/WSAcademiaSeguros.Entities")]
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(ServiceReference1.PolicyDetail))]
    public partial class Policy : object
    {
        
        private string NumberField;
        
        private ServiceReference1.EnumPolicyState StateField;
        
        private ServiceReference1.EnumPolicyType TypeField;
        
        private double ValueField;
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Number
        {
            get
            {
                return this.NumberField;
            }
            set
            {
                this.NumberField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public ServiceReference1.EnumPolicyState State
        {
            get
            {
                return this.StateField;
            }
            set
            {
                this.StateField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public ServiceReference1.EnumPolicyType Type
        {
            get
            {
                return this.TypeField;
            }
            set
            {
                this.TypeField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public double Value
        {
            get
            {
                return this.ValueField;
            }
            set
            {
                this.ValueField = value;
            }
        }
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name="PolicyDetail", Namespace="http://schemas.datacontract.org/2004/07/WSAcademiaSeguros.Entities")]
    public partial class PolicyDetail : ServiceReference1.Policy
    {
        
        private ServiceReference1.PolicyConditions ConditionsField;
        
        private ServiceReference1.PolicyGeneralData GeneralDataField;
        
        private ServiceReference1.PolicyDocument[] ListDocumentsField;
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public ServiceReference1.PolicyConditions Conditions
        {
            get
            {
                return this.ConditionsField;
            }
            set
            {
                this.ConditionsField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public ServiceReference1.PolicyGeneralData GeneralData
        {
            get
            {
                return this.GeneralDataField;
            }
            set
            {
                this.GeneralDataField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public ServiceReference1.PolicyDocument[] ListDocuments
        {
            get
            {
                return this.ListDocumentsField;
            }
            set
            {
                this.ListDocumentsField = value;
            }
        }
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name="EnumPolicyState", Namespace="http://schemas.datacontract.org/2004/07/WSAcademiaSeguros.Entities")]
    public enum EnumPolicyState : int
    {
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        NotDefined = 0,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        Simulated = 1,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        WaitPayment = 2,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        Active = 3,
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name="EnumPolicyType", Namespace="http://schemas.datacontract.org/2004/07/WSAcademiaSeguros.Entities")]
    public enum EnumPolicyType : int
    {
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        NotDefined = 0,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        Auto = 1,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        Travel = 2,
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name="PolicyConditions", Namespace="http://schemas.datacontract.org/2004/07/WSAcademiaSeguros.Entities")]
    public partial class PolicyConditions : object
    {
        
        private ServiceReference1.PolicyBonus[] ListPolicyBonusField;
        
        private ServiceReference1.PolicyCoverage[] ListPolicyCoverageField;
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public ServiceReference1.PolicyBonus[] ListPolicyBonus
        {
            get
            {
                return this.ListPolicyBonusField;
            }
            set
            {
                this.ListPolicyBonusField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public ServiceReference1.PolicyCoverage[] ListPolicyCoverage
        {
            get
            {
                return this.ListPolicyCoverageField;
            }
            set
            {
                this.ListPolicyCoverageField = value;
            }
        }
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name="PolicyGeneralData", Namespace="http://schemas.datacontract.org/2004/07/WSAcademiaSeguros.Entities")]
    public partial class PolicyGeneralData : object
    {
        
        private double BonusInsuranceField;
        
        private string BranchField;
        
        private string BusinessUnitField;
        
        private string ClientNumberField;
        
        private string ConcurrencyField;
        
        private System.DateTime EndDateField;
        
        private string FragmentationField;
        
        private System.DateTime InitDateField;
        
        private string IntermediateField;
        
        private ServiceReference1.PolicyVehicle[] ListVehiclesField;
        
        private string LocalRiskField;
        
        private string PaymentModeField;
        
        private string ProductField;
        
        private double TotalInsuranceField;
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public double BonusInsurance
        {
            get
            {
                return this.BonusInsuranceField;
            }
            set
            {
                this.BonusInsuranceField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Branch
        {
            get
            {
                return this.BranchField;
            }
            set
            {
                this.BranchField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string BusinessUnit
        {
            get
            {
                return this.BusinessUnitField;
            }
            set
            {
                this.BusinessUnitField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string ClientNumber
        {
            get
            {
                return this.ClientNumberField;
            }
            set
            {
                this.ClientNumberField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Concurrency
        {
            get
            {
                return this.ConcurrencyField;
            }
            set
            {
                this.ConcurrencyField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public System.DateTime EndDate
        {
            get
            {
                return this.EndDateField;
            }
            set
            {
                this.EndDateField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Fragmentation
        {
            get
            {
                return this.FragmentationField;
            }
            set
            {
                this.FragmentationField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public System.DateTime InitDate
        {
            get
            {
                return this.InitDateField;
            }
            set
            {
                this.InitDateField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Intermediate
        {
            get
            {
                return this.IntermediateField;
            }
            set
            {
                this.IntermediateField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public ServiceReference1.PolicyVehicle[] ListVehicles
        {
            get
            {
                return this.ListVehiclesField;
            }
            set
            {
                this.ListVehiclesField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string LocalRisk
        {
            get
            {
                return this.LocalRiskField;
            }
            set
            {
                this.LocalRiskField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string PaymentMode
        {
            get
            {
                return this.PaymentModeField;
            }
            set
            {
                this.PaymentModeField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Product
        {
            get
            {
                return this.ProductField;
            }
            set
            {
                this.ProductField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public double TotalInsurance
        {
            get
            {
                return this.TotalInsuranceField;
            }
            set
            {
                this.TotalInsuranceField = value;
            }
        }
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name="PolicyDocument", Namespace="http://schemas.datacontract.org/2004/07/WSAcademiaSeguros.Entities")]
    public partial class PolicyDocument : object
    {
        
        private System.DateTime DataField;
        
        private string DocumentTypeField;
        
        private int IDField;
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public System.DateTime Data
        {
            get
            {
                return this.DataField;
            }
            set
            {
                this.DataField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string DocumentType
        {
            get
            {
                return this.DocumentTypeField;
            }
            set
            {
                this.DocumentTypeField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public int ID
        {
            get
            {
                return this.IDField;
            }
            set
            {
                this.IDField = value;
            }
        }
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name="PolicyBonus", Namespace="http://schemas.datacontract.org/2004/07/WSAcademiaSeguros.Entities")]
    public partial class PolicyBonus : object
    {
        
        private int BonusField;
        
        private int NumberYearsField;
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public int Bonus
        {
            get
            {
                return this.BonusField;
            }
            set
            {
                this.BonusField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public int NumberYears
        {
            get
            {
                return this.NumberYearsField;
            }
            set
            {
                this.NumberYearsField = value;
            }
        }
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name="PolicyCoverage", Namespace="http://schemas.datacontract.org/2004/07/WSAcademiaSeguros.Entities")]
    public partial class PolicyCoverage : object
    {
        
        private string CoverageTypeField;
        
        private double InsuredValueField;
        
        private double ValueField;
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string CoverageType
        {
            get
            {
                return this.CoverageTypeField;
            }
            set
            {
                this.CoverageTypeField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public double InsuredValue
        {
            get
            {
                return this.InsuredValueField;
            }
            set
            {
                this.InsuredValueField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public double Value
        {
            get
            {
                return this.ValueField;
            }
            set
            {
                this.ValueField = value;
            }
        }
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name="PolicyVehicle", Namespace="http://schemas.datacontract.org/2004/07/WSAcademiaSeguros.Entities")]
    public partial class PolicyVehicle : object
    {
        
        private string BrandField;
        
        private int CCField;
        
        private string ModelField;
        
        private uint NSeatField;
        
        private string RegistrationField;
        
        private double WeightField;
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Brand
        {
            get
            {
                return this.BrandField;
            }
            set
            {
                this.BrandField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public int CC
        {
            get
            {
                return this.CCField;
            }
            set
            {
                this.CCField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Model
        {
            get
            {
                return this.ModelField;
            }
            set
            {
                this.ModelField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public uint NSeat
        {
            get
            {
                return this.NSeatField;
            }
            set
            {
                this.NSeatField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Registration
        {
            get
            {
                return this.RegistrationField;
            }
            set
            {
                this.RegistrationField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public double Weight
        {
            get
            {
                return this.WeightField;
            }
            set
            {
                this.WeightField = value;
            }
        }
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    [System.ServiceModel.ServiceContractAttribute(ConfigurationName="ServiceReference1.IAcademia")]
    public interface IAcademia
    {
        
        [System.ServiceModel.OperationContractAttribute(Action="http://tempuri.org/IAcademia/IsOnline", ReplyAction="http://tempuri.org/IAcademia/IsOnlineResponse")]
        System.Threading.Tasks.Task<bool> IsOnlineAsync();
        
        [System.ServiceModel.OperationContractAttribute(Action="http://tempuri.org/IAcademia/LogIn", ReplyAction="http://tempuri.org/IAcademia/LogInResponse")]
        System.Threading.Tasks.Task<bool> LogInAsync(string username, string password);
        
        [System.ServiceModel.OperationContractAttribute(Action="http://tempuri.org/IAcademia/GetUserData", ReplyAction="http://tempuri.org/IAcademia/GetUserDataResponse")]
        System.Threading.Tasks.Task<ServiceReference1.User> GetUserDataAsync();
        
        [System.ServiceModel.OperationContractAttribute(Action="http://tempuri.org/IAcademia/GetLastOperation", ReplyAction="http://tempuri.org/IAcademia/GetLastOperationResponse")]
        System.Threading.Tasks.Task<ServiceReference1.Operation[]> GetLastOperationAsync();
        
        [System.ServiceModel.OperationContractAttribute(Action="http://tempuri.org/IAcademia/GetUserPolicies", ReplyAction="http://tempuri.org/IAcademia/GetUserPoliciesResponse")]
        System.Threading.Tasks.Task<ServiceReference1.Policy[]> GetUserPoliciesAsync();
        
        [System.ServiceModel.OperationContractAttribute(Action="http://tempuri.org/IAcademia/GetPolicyDetail", ReplyAction="http://tempuri.org/IAcademia/GetPolicyDetailResponse")]
        System.Threading.Tasks.Task<ServiceReference1.PolicyDetail> GetPolicyDetailAsync(string policyNumber);
        
        [System.ServiceModel.OperationContractAttribute(Action="http://tempuri.org/IAcademia/GetDocumentContent", ReplyAction="http://tempuri.org/IAcademia/GetDocumentContentResponse")]
        System.Threading.Tasks.Task<string> GetDocumentContentAsync(int ID);
        
        [System.ServiceModel.OperationContractAttribute(Action="http://tempuri.org/IAcademia/SaveNewFoto", ReplyAction="http://tempuri.org/IAcademia/SaveNewFotoResponse")]
        System.Threading.Tasks.Task<bool> SaveNewFotoAsync(string photo);
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    public interface IAcademiaChannel : ServiceReference1.IAcademia, System.ServiceModel.IClientChannel
    {
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.1.0")]
    public partial class AcademiaClient : System.ServiceModel.ClientBase<ServiceReference1.IAcademia>, ServiceReference1.IAcademia
    {
        
        /// <summary>
        /// Implement this partial method to configure the service endpoint.
        /// </summary>
        /// <param name="serviceEndpoint">The endpoint to configure</param>
        /// <param name="clientCredentials">The client credentials</param>
        static partial void ConfigureEndpoint(System.ServiceModel.Description.ServiceEndpoint serviceEndpoint, System.ServiceModel.Description.ClientCredentials clientCredentials);
        
        public AcademiaClient() : 
                base(AcademiaClient.GetDefaultBinding(), AcademiaClient.GetDefaultEndpointAddress())
        {
            this.Endpoint.Name = EndpointConfiguration.BasicHttpBinding_IAcademia.ToString();
            ConfigureEndpoint(this.Endpoint, this.ClientCredentials);
        }
        
        public AcademiaClient(EndpointConfiguration endpointConfiguration) : 
                base(AcademiaClient.GetBindingForEndpoint(endpointConfiguration), AcademiaClient.GetEndpointAddress(endpointConfiguration))
        {
            this.Endpoint.Name = endpointConfiguration.ToString();
            ConfigureEndpoint(this.Endpoint, this.ClientCredentials);
        }
        
        public AcademiaClient(EndpointConfiguration endpointConfiguration, string remoteAddress) : 
                base(AcademiaClient.GetBindingForEndpoint(endpointConfiguration), new System.ServiceModel.EndpointAddress(remoteAddress))
        {
            this.Endpoint.Name = endpointConfiguration.ToString();
            ConfigureEndpoint(this.Endpoint, this.ClientCredentials);
        }
        
        public AcademiaClient(EndpointConfiguration endpointConfiguration, System.ServiceModel.EndpointAddress remoteAddress) : 
                base(AcademiaClient.GetBindingForEndpoint(endpointConfiguration), remoteAddress)
        {
            this.Endpoint.Name = endpointConfiguration.ToString();
            ConfigureEndpoint(this.Endpoint, this.ClientCredentials);
        }
        
        public AcademiaClient(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) : 
                base(binding, remoteAddress)
        {
        }
        
        public System.Threading.Tasks.Task<bool> IsOnlineAsync()
        {
            return base.Channel.IsOnlineAsync();
        }
        
        public System.Threading.Tasks.Task<bool> LogInAsync(string username, string password)
        {
            return base.Channel.LogInAsync(username, password);
        }
        
        public System.Threading.Tasks.Task<ServiceReference1.User> GetUserDataAsync()
        {
            return base.Channel.GetUserDataAsync();
        }
        
        public System.Threading.Tasks.Task<ServiceReference1.Operation[]> GetLastOperationAsync()
        {
            return base.Channel.GetLastOperationAsync();
        }
        
        public System.Threading.Tasks.Task<ServiceReference1.Policy[]> GetUserPoliciesAsync()
        {
            return base.Channel.GetUserPoliciesAsync();
        }
        
        public System.Threading.Tasks.Task<ServiceReference1.PolicyDetail> GetPolicyDetailAsync(string policyNumber)
        {
            return base.Channel.GetPolicyDetailAsync(policyNumber);
        }
        
        public System.Threading.Tasks.Task<string> GetDocumentContentAsync(int ID)
        {
            return base.Channel.GetDocumentContentAsync(ID);
        }
        
        public System.Threading.Tasks.Task<bool> SaveNewFotoAsync(string photo)
        {
            return base.Channel.SaveNewFotoAsync(photo);
        }
        
        public virtual System.Threading.Tasks.Task OpenAsync()
        {
            return System.Threading.Tasks.Task.Factory.FromAsync(((System.ServiceModel.ICommunicationObject)(this)).BeginOpen(null, null), new System.Action<System.IAsyncResult>(((System.ServiceModel.ICommunicationObject)(this)).EndOpen));
        }
        
        public virtual System.Threading.Tasks.Task CloseAsync()
        {
            return System.Threading.Tasks.Task.Factory.FromAsync(((System.ServiceModel.ICommunicationObject)(this)).BeginClose(null, null), new System.Action<System.IAsyncResult>(((System.ServiceModel.ICommunicationObject)(this)).EndClose));
        }
        
        private static System.ServiceModel.Channels.Binding GetBindingForEndpoint(EndpointConfiguration endpointConfiguration)
        {
            if ((endpointConfiguration == EndpointConfiguration.BasicHttpBinding_IAcademia))
            {
                System.ServiceModel.BasicHttpBinding result = new System.ServiceModel.BasicHttpBinding();
                result.MaxBufferSize = int.MaxValue;
                result.ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max;
                result.MaxReceivedMessageSize = int.MaxValue;
                result.AllowCookies = true;
                return result;
            }
            throw new System.InvalidOperationException(string.Format("Could not find endpoint with name \'{0}\'.", endpointConfiguration));
        }
        
        private static System.ServiceModel.EndpointAddress GetEndpointAddress(EndpointConfiguration endpointConfiguration)
        {
            if ((endpointConfiguration == EndpointConfiguration.BasicHttpBinding_IAcademia))
            {
                return new System.ServiceModel.EndpointAddress("http://academianet.itsector.local/Academia.svc");
            }
            throw new System.InvalidOperationException(string.Format("Could not find endpoint with name \'{0}\'.", endpointConfiguration));
        }
        
        private static System.ServiceModel.Channels.Binding GetDefaultBinding()
        {
            return AcademiaClient.GetBindingForEndpoint(EndpointConfiguration.BasicHttpBinding_IAcademia);
        }
        
        private static System.ServiceModel.EndpointAddress GetDefaultEndpointAddress()
        {
            return AcademiaClient.GetEndpointAddress(EndpointConfiguration.BasicHttpBinding_IAcademia);
        }
        
        public enum EndpointConfiguration
        {
            
            BasicHttpBinding_IAcademia,
        }
    }
}
